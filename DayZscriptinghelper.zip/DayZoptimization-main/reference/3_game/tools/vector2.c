class Vector2
{	
	void Vector2(float value_x, float value_y)
	{
		x = value_x;
		y = value_y;
	}
	
	float x;
	float y;
};