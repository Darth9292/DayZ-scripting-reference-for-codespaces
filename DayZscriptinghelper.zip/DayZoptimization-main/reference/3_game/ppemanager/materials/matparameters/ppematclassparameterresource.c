class PPEMatClassParameterResource extends PPEMatClassParameterCommandData
{
	override int GetParameterVarType()
	{
		return PPEConstants.VAR_TYPE_RESOURCE;
	}
}
