class PPEMatClassParameterVector extends PPEMatClassParameterCommandData
{
	override int GetParameterVarType()
	{
		return PPEConstants.VAR_TYPE_VECTOR;
	}
}
