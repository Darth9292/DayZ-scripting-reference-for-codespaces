enum EBuildingLockType
{
	NONE = 0, //unlockable only via script
	LOCKPICK,
	SHIP_CONTAINER_0,
	SHIP_CONTAINER_1,
	SHIP_CONTAINER_2,
	SHIP_CONTAINER_3,
}