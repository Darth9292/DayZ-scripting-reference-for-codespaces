enum eBrokenLegs
{
	NO_BROKEN_LEGS = 0,
	BROKEN_LEGS = 1,
	BROKEN_LEGS_SPLINT = 2,
}