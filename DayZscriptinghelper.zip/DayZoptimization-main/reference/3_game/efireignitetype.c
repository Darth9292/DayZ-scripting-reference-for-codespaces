enum EFireIgniteType
{
	Unknow,
	Matchbox,
	Roadflare,
	HandDrill,
}