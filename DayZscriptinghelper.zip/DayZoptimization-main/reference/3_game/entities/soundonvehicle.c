class SoundOnVehicle extends Entity
{
	proto native float GetSoundLength();
};

class SoundWaveOnVehicle extends Entity
{
};
