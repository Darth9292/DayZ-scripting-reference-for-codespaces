
//! base "helper" class for nonlethal ammo handling
class Nonlethal_Base {};
class Bullet_12GaugeRubberSlug: Nonlethal_Base {};