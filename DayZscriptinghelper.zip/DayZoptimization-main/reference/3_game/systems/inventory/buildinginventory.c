/**@class		BuildingInventory
 * @brief		inventory for buildings (also called "proxy cargo")
 **/
class BuildingInventory : GameInventory
{
	//proto native bool HasProxyCargo();
	//proto native int GetProxyCargoCount();
	//proto native Cargo GetProxyCargo(int cargoIndex);
};

