/**@class		TransportInventory
 * @brief		inventory for transport ("man cargo")
 **/
class TransportInventory : GameInventory
{
};

