/**@class		WeaponInventory
 * @brief		inventory for weapons
 **/
class WeaponInventory : ItemInventory
{
};

proto native bool TryFireWeapon(EntityAI weapon, int muzzleIndex);
