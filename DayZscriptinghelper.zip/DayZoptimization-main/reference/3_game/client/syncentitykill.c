class SyncEntityKillInfo
{
	EntityAI	m_EntityVictim;
	EntityAI	m_EntityKiller;
	EntityAI	m_EntitySource;
	bool		m_IsHeadShot;
}