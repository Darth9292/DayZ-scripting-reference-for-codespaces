class SyncData
{
	int m_SyncInt;
	ref SyncPlayerList m_ServerPlayerList;
	ref SyncEntityKillInfo m_EntityKill;
}