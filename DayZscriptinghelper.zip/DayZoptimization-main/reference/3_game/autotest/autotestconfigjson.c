class AutotestConfigJson
{
	ref set<string> TestSuites;
}