class JsonDataCreditsDepartment : Managed
{
	string DepartmentName;
	ref array<ref JsonDataCreditsSection> Sections;
};

