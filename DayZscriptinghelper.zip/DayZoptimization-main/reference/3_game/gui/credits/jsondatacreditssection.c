class JsonDataCreditsSection : Managed
{
	string SectionName;
	ref array<string> SectionLines;
};

