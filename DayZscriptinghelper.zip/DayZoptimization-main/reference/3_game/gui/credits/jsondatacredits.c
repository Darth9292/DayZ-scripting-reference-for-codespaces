class JsonDataCredits : Managed
{
	ref array<ref JsonDataCreditsDepartment> Departments;
};

