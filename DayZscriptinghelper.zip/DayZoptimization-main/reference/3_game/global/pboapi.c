class PBOAPI
{
	proto native owned string GetPBOVersion(string openName);
}

static proto native PBOAPI GetPBOAPI();