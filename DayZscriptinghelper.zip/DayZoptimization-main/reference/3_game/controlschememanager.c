class ControlSchemeManager
{
	//! leaving it here in case that someone using it inside a mod
	static void SetControlScheme( EControlSchemeState state )
	{
		return;
	}
}