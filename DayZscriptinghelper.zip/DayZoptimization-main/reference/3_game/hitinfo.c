class HitInfo
{
	proto native float GetSurfaceNoiseMultiplier();
	proto native string GetAmmoType();
	proto native vector GetPosition();
	proto native vector GetSurfaceNormal();
	proto native string GetSurface();
	proto native bool IsWater();
}