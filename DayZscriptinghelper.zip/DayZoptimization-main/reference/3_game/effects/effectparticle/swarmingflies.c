class EffSwarmingFlies : EffectParticle
{
	void EffSwarmingFlies()
 	{
		SetParticleID(ParticleList.ENV_SWARMING_FLIES);
	}
}
