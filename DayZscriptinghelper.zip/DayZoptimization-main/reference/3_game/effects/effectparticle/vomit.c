class EffVomit : EffectParticle
{
	void EffVomit()
	{
		SetParticleID(ParticleList.VOMIT);
	}
}