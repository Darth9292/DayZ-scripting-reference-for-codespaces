class BleedingSourceEffect : EffectParticle
{
	void BleedingSourceEffect()
	{
		SetParticleID(ParticleList.BLEEDING_SOURCE);
	}
}

class BleedingSourceEffectLight : EffectParticle
{
	void BleedingSourceEffectLight()
	{
		SetParticleID(ParticleList.BLEEDING_SOURCE_LIGHT);
	}
}