class MenuCarEngineSmoke : EffectParticle
{
	void MenuCarEngineSmoke()
	{
		SetParticleID(ParticleList.SMOKING_CAR_ENGINE);
	}
}