class Hit_Undefined : EffBulletImpactBase
{
	void Hit_Undefined()
	{
		SetSingleParticle(ParticleList.IMPACT_TEST);
	}
}