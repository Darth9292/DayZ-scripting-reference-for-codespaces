class Hit_MeatBones_MeleeWrench : Hit_MeatBones
{
	void Hit_MeatBones_MeleeWrench()
	{

	}
}