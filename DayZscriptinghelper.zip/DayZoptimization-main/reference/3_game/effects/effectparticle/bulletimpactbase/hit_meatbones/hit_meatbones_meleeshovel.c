class Hit_MeatBones_MeleeShovel : Hit_MeatBones
{
	void Hit_MeatBones_MeleeShovel()
	{

	}
}