class Hit_MeatBones_MeleeFist : Hit_MeatBones
{
	void Hit_MeatBones_MeleeFist()
	{
		SetSingleParticle(ParticleList.INVALID);
	}
}