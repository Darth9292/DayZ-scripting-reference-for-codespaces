class Hit_MeatBones_MeleePipeWrench : Hit_MeatBones
{
	void Hit_MeatBones_MeleePipeWrench()
	{

	}
}