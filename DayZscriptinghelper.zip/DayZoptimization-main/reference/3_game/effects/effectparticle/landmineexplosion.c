class LandmineExplosion : EffectParticle
{
	void LandmineExplosion()
	{
		SetParticleID(ParticleList.EXPLOSION_LANDMINE);
	}
}