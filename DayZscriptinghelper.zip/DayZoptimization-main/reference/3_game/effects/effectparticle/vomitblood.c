class EffVomitBlood : EffectParticle
{
	void EffVomitBlood()
	{
		SetParticleID(ParticleList.VOMIT_BLOOD);
	}
}