class EffBulletImpactTest : EffectParticle
{
	void EffBulletImpactTest()
	{
		SetParticleID(ParticleList.IMPACT_TEST);
	}
}