class BloodSplatter : EffectParticle
{
	void BloodSplatter()
	{
		SetParticleID(ParticleList.BLOOD_SURFACE_DROPS);
	}
}