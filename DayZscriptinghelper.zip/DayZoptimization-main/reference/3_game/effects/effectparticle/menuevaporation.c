class MenuEvaporation : EffectParticle
{
	void MenuEvaporation()
	{
		SetParticleID(ParticleList.EVAPORATION);
	}
}