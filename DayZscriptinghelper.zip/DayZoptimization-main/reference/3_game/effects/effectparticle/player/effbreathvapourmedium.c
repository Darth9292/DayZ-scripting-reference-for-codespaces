class EffBreathVapourMedium : EffectParticle
{	
	void EffBreathVapourMedium()
	{
		SetParticleID(ParticleList.BREATH_VAPOUR_MEDIUM);
	}
}