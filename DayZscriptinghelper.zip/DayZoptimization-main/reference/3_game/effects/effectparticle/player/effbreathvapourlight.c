class EffBreathVapourLight : EffectParticle
{	
	void EffBreathVapourLight()
 	{
		SetParticleID(ParticleList.BREATH_VAPOUR_LIGHT);
	}
}