class EffBreathVapourHeavy : EffectParticle
{
	void EffBreathVapourHeavy()
	{
		SetParticleID(ParticleList.BREATH_VAPOUR_HEAVY);
	}
}