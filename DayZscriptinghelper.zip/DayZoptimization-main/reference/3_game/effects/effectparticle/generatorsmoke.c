class EffGeneratorSmoke : EffectParticle
{
	void EffGeneratorSmoke()
	{
		SetParticleID(ParticleList.POWER_GENERATOR_SMOKE);
	}
}