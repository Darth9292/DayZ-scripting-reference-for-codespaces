enum EControlSchemeState
{
	None,
	WeaponIronSight,
	WeaponGun,
	WeaponMelee,
	VehicleDriver,
	UI
}