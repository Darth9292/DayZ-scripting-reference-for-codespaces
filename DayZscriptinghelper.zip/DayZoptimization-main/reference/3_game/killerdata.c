class KillerData
{
	EntityAI 	m_Killer;
	EntityAI 	m_MurderWeapon; //can be fists, so no ItemBase possible
	bool 		m_KillerHiTheBrain;
}
