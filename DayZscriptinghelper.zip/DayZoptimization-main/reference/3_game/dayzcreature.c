enum DayZCreatureAnimScriptDebugVarType
{
	INT,
	FLOAT,
	BOOL,
};