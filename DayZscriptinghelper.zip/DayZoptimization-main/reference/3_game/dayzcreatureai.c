enum DayZCreatureAIConstants
{
	DEBUG_SHOWDEBUGPLUGIN
};