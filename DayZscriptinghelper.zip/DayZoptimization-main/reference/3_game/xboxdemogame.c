//global variables for xbox demo purposes
int g_DemoPlayerClass 	= 0;
int g_DemoWeather 		= 0;
int g_DemoTimeOfDay 	= 0;
//