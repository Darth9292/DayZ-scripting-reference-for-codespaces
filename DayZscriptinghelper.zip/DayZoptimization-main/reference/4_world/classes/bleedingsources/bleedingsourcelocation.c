class BleedingSourceLocation
{
	void BleedingSourceLocation()
	{

	}

	void ~BleedingSourceLocation()
	{
	
	}
}