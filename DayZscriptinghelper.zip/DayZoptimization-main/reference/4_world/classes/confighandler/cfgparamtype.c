class CfgParamType extends CfgParam
{	
	void CfgParamType(string param_name)
	{
		
	}
}