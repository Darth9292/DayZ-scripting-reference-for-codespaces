//some example "reference" variables for use in material editor
reference float g_testVariable1;
reference float g_testVariable2;
reference float g_testVariable3;

class TestClass
{
	//some example "reference" variables for use in material editor
	reference float testVar1;
	reference float testVar2;
	reference float testVar3;
}
